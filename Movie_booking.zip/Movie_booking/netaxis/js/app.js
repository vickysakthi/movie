var movieapp = angular.module("myapp", ['ngRoute']);

movieapp.config(function ($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "pages/loginpage.html",
      controller: "loginpageController",
    })
    .when("/registerpage", {
      templateUrl: "pages/registerpage.html",
      controller: "registerController",
    })
    .when("/userpage", {
      templateUrl: "pages/userpage.html",
      controller: "userController",
    })
    .when("/adminpage", {
      templateUrl: "pages/adminpage.html",
      controller: "adminpageController",
    })
    .when("/searchpage",{
      templateUrl:'pages/searchpage.html',
      controller:'searchpageController'
    })
    .otherwise({
      redirectTo: '/'
    });

});

// movieapp.factory('DataService', function($http) {
//   var movies = [];
//   var beverages = [];

//   function fetchMovies() {
//     return $http.get('movies.json').then(function(response) {
//       movies = response.data.movies;
//       return movies;
//     }, function(error) {
//       console.error('Error loading movies:', error);
//     });
//   }

//   fetchMovies();
  
//   return {
//     getMovies: function() {
//       return movies;
//     },
//     updateMovie: function(updatedMovie) {
//       for (var i = 0; i < movies.length; i++) {
//         if (movies[i].id === updatedMovie.id) {
//           movies[i] = updatedMovie;
//           break;
//         }
//       }
//     },
//     setMovies: function(newMovies) {
//       movies = newMovies;
//     },
    
//     fetchMovies: fetchMovies
//   };
  
// });
movieapp.factory('DataService', function() {
  var movies = [];
  var beverages = []; 

  return {
    getMovies: function() {
      return movies;
    },
    updateMovie: function(updatedMovie) {
      for (var i = 0; i < movies.length; i++) {
        if (movies[i].id === updatedMovie.id) {
          movies[i] = updatedMovie;
          break;
        }
      }
    },
    setMovies: function(newMovies) {
      movies = newMovies;
    },
    resetMovies: function() {
      movies = [];
    },
    getBeverages: function() {
      return beverages;
    },
    setBeverages: function(newBeverages) {
      beverages = newBeverages;
    }
  };
});


movieapp.controller("registerController", function ($scope) {
  $scope.user = {};
  $scope.register = function() {
    if ($scope.registerForm.$valid) {
      localStorage.setItem($scope.user.username, JSON.stringify($scope.user));
      alert('Registration successful');
      window.location.href = "#!/";
    } else {
      alert('Please fill all required fields.');
    }
  };
});

movieapp.controller("loginpageController", function ($scope, $location) {
  $scope.loginData = {};
  $scope.login = function() {
    if ($scope.loginData.username === "admin" && $scope.loginData.password === "admin") {
      alert('Admin login successful');
      window.location.href = "#!/adminpage";
    } else {
      let storedUser = JSON.parse(localStorage.getItem($scope.loginData.username));
      if (storedUser && storedUser.password === $scope.loginData.password) {
        localStorage.setItem('currentUser', JSON.stringify(storedUser));
        alert('Login successful');
        $location.path('/userpage').search({ username: storedUser.username });
      } else {
        alert('Invalid username or password');
      }
    }
  };
});

// movieapp.controller("userController", function ($scope, $location, DataService) {
//   $scope.bookingMessage = ''; 
//   $scope.showBooking = false;
//   $scope.showBeverage = false;
  
//   var currentUser = JSON.parse(localStorage.getItem('currentUser'));
//   if (!currentUser) {
//     $location.path('/');
//     return;
//   }
//   $scope.username = currentUser.username;

//   $scope.movies = DataService.getMovies();

//   $scope.$watch(function() {
//     return DataService.getMovies();
//   }, function(newVal, oldVal) {
//     if (newVal !== oldVal) {
//       $scope.movies = newVal; // Update scope movies when DataService movies change
//     }
//   }, true);

//   $scope.bookticket = function() {
//     $scope.bookingMessage = 'Your ticket booking process has started!';
//     $scope.showBooking = true;
//     $scope.showBeverage = false;
//   };

//   $scope.bevarage = function() {
//     $scope.bookingMessage = 'No Beverages show';
//     $scope.showBooking = false;
//     $scope.showBeverage = true;
//   };

//   $scope.approveMovie = function(movie) {
//     alert('Booking for ' + movie.title + ' approved!');
//   };
// });

movieapp.controller("userController", function ($scope, $location, $http, DataService) {
  $scope.bookingMessage = ''; 
  $scope.showBooking = false;
  $scope.showBeverage = false;
  
  var currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) {
    $location.path('/');
    return;
  }
  $scope.username = currentUser.username;

  // Initialize movies from DataService
  $scope.movies = DataService.getMovies();

  // Fetch beverages data
  $http.get('beverages.json')
    .then(function(res){
      $scope.beverages = res.data.beverages;
      DataService.setBeverages($scope.beverages); // Set beverages in DataService
    }, function(error) {
      console.error('Error loading beverages:', error);
    });

  $scope.bookticket = function() {
    $scope.bookingMessage = 'Your ticket booking process has started!';
    $scope.showBooking = true;
    $scope.showBeverage = false;
  };

  $scope.bevarage = function() {
    $scope.bookingMessage = 'Available Beverages';
    $scope.showBooking = false;
    $scope.showBeverage = true;
  };

  // Watch for changes in DataService movies
  $scope.$watch(function() {
    return DataService.getMovies();
  }, function(newVal, oldVal) {
    if (newVal !== oldVal) {
      $scope.movies = newVal;
    }
  }, true);

  // Watch for changes in DataService beverages
  $scope.$watch(function() {
    return DataService.getBeverages();
  }, function(newVal, oldVal) {
    if (newVal !== oldVal) {
      $scope.beverages = newVal;
    }
  }, true);
});



movieapp.controller("adminpageController", function ($scope, DataService, $http, $location) {
  $scope.message = 'Approve The Movie';
  
  // Fetch movies data
  $http.get('movies.json')
    .then(function(res){
      $scope.movies = res.data.movies;
      DataService.setMovies($scope.movies); // Set movies in DataService
    }, function(error) {
      console.error('Error loading movies:', error);
    });

  // Fetch beverages data
  $http.get('beverages.json')
    .then(function(res){
      $scope.beverages = res.data.beverages;
      DataService.setBeverages($scope.beverages); 
    }, function(error) {
      console.error('Error loading beverages:', error);
    });
    
  $scope.approveMovie = function(movie) {
    movie.approved = true;
    DataService.updateMovie(movie); 
  };

  $scope.approveUser = function(user) {
    alert('User ' + user.username + ' approved!');
  };
});


movieapp.controller("searchpageController",function($scope){
  $scope.message = "filtered data"
})






